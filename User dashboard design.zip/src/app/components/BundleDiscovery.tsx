import { Package, ChevronDown, Zap } from "lucide-react";
import { useState } from "react";

const products = [
  { name: "Avocado", emoji: "🥑" },
  { name: "Banana", emoji: "🍌" },
  { name: "Strawberries", emoji: "🍓" },
  { name: "Lime", emoji: "🍋" },
  { name: "Cilantro", emoji: "🌿" },
  { name: "Tomato", emoji: "🍅" },
  { name: "Onion", emoji: "🧅" },
  { name: "Garlic", emoji: "🧄" },
];

interface BundleResult {
  lift: string;
  confidence: string;
  support: string;
  suggestion: string;
}

const bundleResults: Record<string, BundleResult> = {
  "Avocado+Lime": { lift: "7.23", confidence: "68%", support: "12.4%", suggestion: "Add Cilantro for Guacamole Bundle!" },
  "Avocado+Cilantro": { lift: "7.89", confidence: "72%", support: "11.1%", suggestion: "Classic Guacamole trio — add Lime!" },
  "Banana+Strawberries": { lift: "4.51", confidence: "54%", support: "9.8%", suggestion: "Smoothie bundle opportunity!" },
  "Lime+Cilantro": { lift: "6.67", confidence: "61%", support: "10.5%", suggestion: "Mexican cuisine pairing — add Avocado!" },
};

function getBundleKey(a: string, b: string) {
  return [a, b].sort().join("+");
}

export function BundleDiscovery() {
  const [productA, setProductA] = useState("Avocado");
  const [productB, setProductB] = useState("Lime");
  const [result, setResult] = useState<BundleResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleCalculate = () => {
    if (productA === productB) return;
    setLoading(true);
    setTimeout(() => {
      const key = getBundleKey(productA, productB);
      setResult(bundleResults[key] || { lift: "3.12", confidence: "41%", support: "6.3%", suggestion: "Moderate pairing detected." });
      setLoading(false);
    }, 600);
  };

  return (
    <div
      className="rounded-[12px] p-6 flex flex-col"
      style={{
        background: "var(--card)",
        boxShadow: "0 2px 12px rgba(46,125,50,0.08), 0 1px 3px rgba(0,0,0,0.05)",
        border: "1px solid var(--border)",
      }}
    >
      <div className="flex items-center gap-2 mb-5">
        <Package className="w-5 h-5" style={{ color: "#2E7D32" }} />
        <h3 style={{ color: "var(--foreground)", margin: 0 }}>Bundle Discovery</h3>
      </div>

      <p style={{ fontSize: "0.875rem", color: "var(--muted-foreground)", marginBottom: "20px" }}>
        Find high-lift product pairs using market basket analysis.
      </p>

      <div className="flex flex-col gap-3 mb-4">
        {[{ value: productA, set: setProductA, label: "Product A" }, { value: productB, set: setProductB, label: "Product B" }].map(({ value, set, label }) => (
          <div key={label} className="relative">
            <label style={{ fontSize: "0.75rem", fontWeight: 600, color: "var(--muted-foreground)", textTransform: "uppercase", letterSpacing: "0.06em", display: "block", marginBottom: "6px" }}>
              {label}
            </label>
            <div className="relative">
              <select
                value={value}
                onChange={(e) => { set(e.target.value); setResult(null); }}
                className="w-full appearance-none rounded-[10px] px-4 py-3 pr-10 outline-none transition-all"
                style={{
                  background: "var(--input-background)",
                  border: "1.5px solid var(--border)",
                  color: "var(--foreground)",
                  fontSize: "0.9375rem",
                  minHeight: "44px",
                  cursor: "pointer",
                }}
                onFocus={(e) => (e.target.style.borderColor = "#2E7D32")}
                onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
              >
                {products.map((p) => (
                  <option key={p.name} value={p.name}>{p.emoji} {p.name}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none" style={{ color: "var(--muted-foreground)" }} />
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={handleCalculate}
        disabled={productA === productB || loading}
        className="w-full rounded-[10px] py-3 flex items-center justify-center gap-2 transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
        style={{
          background: "#2E7D32",
          color: "#fff",
          fontWeight: 600,
          fontSize: "0.9375rem",
          minHeight: "44px",
          border: "none",
          cursor: productA === productB ? "not-allowed" : "pointer",
        }}
      >
        <Zap className="w-4 h-4" />
        {loading ? "Calculating…" : "Calculate Bundle"}
      </button>

      {result && (
        <div
          className="mt-4 rounded-[10px] p-4"
          style={{ background: "#E8F5E9", border: "1.5px solid #A5D6A7" }}
        >
          <div className="grid grid-cols-3 gap-3 mb-3">
            {[
              { label: "Lift", val: result.lift },
              { label: "Confidence", val: result.confidence },
              { label: "Support", val: result.support },
            ].map(({ label, val }) => (
              <div key={label} className="text-center">
                <p style={{ fontSize: "1.25rem", fontWeight: 700, color: "#2E7D32", margin: 0 }}>{val}</p>
                <p style={{ fontSize: "0.75rem", color: "#5A7A5A", margin: 0 }}>{label}</p>
              </div>
            ))}
          </div>
          <p style={{ fontSize: "0.875rem", color: "#2E7D32", fontWeight: 500, margin: 0, textAlign: "center" }}>
            💡 {result.suggestion}
          </p>
        </div>
      )}
    </div>
  );
}
