import { Search, X, TrendingUp } from "lucide-react";
import { useState } from "react";

const recommendations = [
  { name: "Banana", emoji: "🍌", lift: "5.89", color: "#FFFDE7", textColor: "#F9A825" },
  { name: "Strawberries", emoji: "🍓", lift: "4.72", color: "#FCE4EC", textColor: "#C62828" },
  { name: "Avocado", emoji: "🥑", lift: "6.14", color: "#E8F5E9", textColor: "#2E7D32" },
];

const searchResults: Record<string, { name: string; emoji: string; category: string; sales: string; lift: string }[]> = {
  banana: [{ name: "Banana", emoji: "🍌", category: "Fresh Produce", sales: "12,840 units", lift: "5.89" }],
  strawberr: [{ name: "Strawberries", emoji: "🍓", category: "Fresh Produce", sales: "8,210 units", lift: "4.72" }],
  avocado: [{ name: "Avocado", emoji: "🥑", category: "Fresh Produce", sales: "9,450 units", lift: "6.14" }],
  apple: [
    { name: "Gala Apple", emoji: "🍎", category: "Fresh Produce", sales: "11,320 units", lift: "4.10" },
    { name: "Granny Smith Apple", emoji: "🍏", category: "Fresh Produce", sales: "7,860 units", lift: "3.88" },
  ],
  lime: [{ name: "Lime", emoji: "🍋", category: "Fresh Produce", sales: "5,670 units", lift: "3.44" }],
};

function getResults(query: string) {
  if (!query.trim()) return [];
  const q = query.toLowerCase();
  for (const key of Object.keys(searchResults)) {
    if (q.includes(key) || key.includes(q)) return searchResults[key];
  }
  return [];
}

export function ProductLookup() {
  const [query, setQuery] = useState("");
  const results = getResults(query);

  return (
    <section>
      <div
        className="rounded-[12px] p-6"
        style={{
          background: "var(--card)",
          boxShadow: "0 2px 12px rgba(46,125,50,0.08), 0 1px 3px rgba(0,0,0,0.05)",
          border: "1px solid var(--border)",
        }}
      >
        {/* Section header */}
        <div className="flex items-center gap-2 mb-5">
          <span style={{ fontSize: "1.25rem" }}>🔍</span>
          <h2 style={{ color: "var(--foreground)", margin: 0 }}>Product Lookup</h2>
        </div>

        {/* Search bar */}
        <div className="relative mb-5">
          <Search
            className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4"
            style={{ color: "var(--muted-foreground)" }}
          />
          <input
            type="text"
            placeholder="Search for a product..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full rounded-[10px] pl-11 pr-10 py-3 transition-all outline-none"
            style={{
              background: "var(--input-background)",
              border: "1.5px solid transparent",
              color: "var(--foreground)",
              fontSize: "0.9375rem",
            }}
            onFocus={(e) => (e.target.style.borderColor = "#2E7D32")}
            onBlur={(e) => (e.target.style.borderColor = "transparent")}
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-gray-100"
            >
              <X className="w-4 h-4" style={{ color: "var(--muted-foreground)" }} />
            </button>
          )}
        </div>

        {/* Search results */}
        {results.length > 0 && (
          <div className="mb-5 rounded-[10px] overflow-hidden" style={{ border: "1px solid var(--border)" }}>
            {results.map((r, i) => (
              <div
                key={r.name}
                className="flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors cursor-pointer"
                style={{ borderTop: i > 0 ? "1px solid var(--border)" : "none" }}
              >
                <div className="flex items-center gap-3">
                  <span style={{ fontSize: "1.5rem" }}>{r.emoji}</span>
                  <div>
                    <p style={{ fontWeight: 600, color: "var(--foreground)", margin: 0 }}>{r.name}</p>
                    <p style={{ fontSize: "0.8125rem", color: "var(--muted-foreground)", margin: 0 }}>{r.category} · {r.sales}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-full" style={{ background: "#E8F5E9" }}>
                  <TrendingUp className="w-3.5 h-3.5" style={{ color: "#2E7D32" }} />
                  <span style={{ fontSize: "0.8125rem", fontWeight: 600, color: "#2E7D32" }}>Lift {r.lift}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Top Recommendations */}
        <div>
          <p style={{ fontSize: "0.8125rem", fontWeight: 600, color: "var(--muted-foreground)", textTransform: "uppercase", letterSpacing: "0.06em", marginBottom: "12px" }}>
            Top Recommendations
          </p>
          <div className="flex flex-wrap gap-2">
            {recommendations.map((rec) => (
              <button
                key={rec.name}
                onClick={() => setQuery(rec.name)}
                className="flex items-center gap-2 px-3.5 py-2 rounded-full transition-all hover:scale-105 active:scale-95"
                style={{
                  background: rec.color,
                  border: `1.5px solid ${rec.textColor}30`,
                  minHeight: "44px",
                }}
              >
                <span style={{ fontSize: "1rem" }}>{rec.emoji}</span>
                <span style={{ fontWeight: 600, color: rec.textColor, fontSize: "0.875rem" }}>{rec.name}</span>
                <span
                  className="px-1.5 py-0.5 rounded-full"
                  style={{ background: rec.textColor + "22", fontSize: "0.75rem", fontWeight: 700, color: rec.textColor }}
                >
                  Lift {rec.lift}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
