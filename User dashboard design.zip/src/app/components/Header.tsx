import { ShoppingCart, Menu, X, Calendar } from "lucide-react";
import { useState } from "react";

const navLinks = ["Overview", "Products", "Customers", "Bundles", "Reports"];

interface HeaderProps {
  selectedDate: string;
  onDateChange: (date: string) => void;
}

export function Header({ selectedDate, onDateChange }: HeaderProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50">
      {/* Green gradient bar */}
      <div
        style={{
          background: "linear-gradient(90deg, #1B5E20 0%, #2E7D32 40%, #388E3C 70%, #43A047 100%)",
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(255,255,255,0.2)" }}>
              <ShoppingCart className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="text-white font-semibold tracking-tight" style={{ fontSize: "1.1rem" }}>
                FreshMart
              </span>
              <span className="text-white/60 ml-2 hidden sm:inline" style={{ fontSize: "0.75rem", fontWeight: 400 }}>
                Retail Intelligence
              </span>
            </div>
          </div>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <a
                key={link}
                href="#"
                className="text-white/80 hover:text-white transition-colors"
                style={{ fontSize: "0.875rem", fontWeight: 500 }}
              >
                {link}
              </a>
            ))}
          </nav>

          {/* Date selector + mobile hamburger */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 rounded-lg px-3 py-1.5"
              style={{ background: "rgba(255,255,255,0.15)" }}>
              <Calendar className="w-4 h-4 text-white/80" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => onDateChange(e.target.value)}
                className="bg-transparent text-white border-none outline-none cursor-pointer"
                style={{ fontSize: "0.8125rem", colorScheme: "dark" }}
              />
            </div>
            <button
              className="md:hidden p-2 rounded-lg text-white"
              style={{ background: "rgba(255,255,255,0.15)", minHeight: "44px", minWidth: "44px" }}
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden"
          style={{ background: "#1B5E20" }}>
          <div className="px-4 py-3 flex flex-col gap-1">
            {navLinks.map((link) => (
              <a
                key={link}
                href="#"
                className="text-white/90 py-2.5 px-3 rounded-lg hover:bg-white/10 transition-colors"
                style={{ fontSize: "0.9375rem", minHeight: "44px", display: "flex", alignItems: "center" }}
                onClick={() => setMobileOpen(false)}
              >
                {link}
              </a>
            ))}
            <div className="flex items-center gap-2 mt-2 px-3 py-2.5 rounded-lg"
              style={{ background: "rgba(255,255,255,0.1)" }}>
              <Calendar className="w-4 h-4 text-white/80" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => onDateChange(e.target.value)}
                className="bg-transparent text-white border-none outline-none"
                style={{ fontSize: "0.875rem", colorScheme: "dark" }}
              />
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
