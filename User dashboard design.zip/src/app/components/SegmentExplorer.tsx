import { Users, ChevronRight } from "lucide-react";
import { useState } from "react";

const segments = [
  {
    name: "Champions",
    emoji: "🏆",
    count: "24,810",
    color: "#E8F5E9",
    textColor: "#2E7D32",
    borderColor: "#A5D6A7",
    desc: "High frequency, high spend",
  },
  {
    name: "At Risk",
    emoji: "⚠️",
    count: "18,340",
    color: "#FFF3E0",
    textColor: "#E65100",
    borderColor: "#FFCC80",
    desc: "Declining purchase frequency",
  },
  {
    name: "Hibernating",
    emoji: "💤",
    count: "31,620",
    color: "#EDE7F6",
    textColor: "#4527A0",
    borderColor: "#CE93D8",
    desc: "No purchase in 90+ days",
  },
  {
    name: "Loyal",
    emoji: "❤️",
    count: "42,110",
    color: "#FCE4EC",
    textColor: "#AD1457",
    borderColor: "#F48FB1",
    desc: "Regular repeat customers",
  },
];

export function SegmentExplorer() {
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div
      className="rounded-[12px] p-6 flex flex-col"
      style={{
        background: "var(--card)",
        boxShadow: "0 2px 12px rgba(46,125,50,0.08), 0 1px 3px rgba(0,0,0,0.05)",
        border: "1px solid var(--border)",
      }}
    >
      <div className="flex items-center gap-2 mb-5">
        <Users className="w-5 h-5" style={{ color: "#2E7D32" }} />
        <h3 style={{ color: "var(--foreground)", margin: 0 }}>Customer Segments</h3>
      </div>

      <div className="flex flex-col gap-3 flex-1">
        {segments.map((seg) => (
          <button
            key={seg.name}
            onClick={() => setSelected(selected === seg.name ? null : seg.name)}
            className="flex items-center gap-3 px-4 py-3 rounded-[10px] text-left transition-all hover:scale-[1.01] active:scale-[0.99]"
            style={{
              background: selected === seg.name ? seg.color : "var(--secondary)",
              border: `1.5px solid ${selected === seg.name ? seg.borderColor : "var(--border)"}`,
              minHeight: "44px",
            }}
          >
            <span style={{ fontSize: "1.25rem" }}>{seg.emoji}</span>
            <div className="flex-1 min-w-0">
              <p style={{ fontWeight: 600, color: selected === seg.name ? seg.textColor : "var(--foreground)", margin: 0, fontSize: "0.9375rem" }}>
                {seg.name}
              </p>
              {selected === seg.name && (
                <p style={{ fontSize: "0.8125rem", color: seg.textColor, margin: 0, opacity: 0.8 }}>{seg.desc}</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span
                className="px-2 py-0.5 rounded-full"
                style={{
                  background: selected === seg.name ? seg.textColor + "22" : "var(--muted)",
                  fontSize: "0.8125rem",
                  fontWeight: 700,
                  color: selected === seg.name ? seg.textColor : "var(--muted-foreground)",
                }}
              >
                {seg.count}
              </span>
              <ChevronRight className="w-4 h-4" style={{ color: "var(--muted-foreground)" }} />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
